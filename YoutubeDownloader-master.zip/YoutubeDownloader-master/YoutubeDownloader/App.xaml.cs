﻿using System;
using System.Reflection;
using System.Windows.Media;
using MaterialDesignThemes.Wpf;
using YoutubeDownloader.Utils;

namespace YoutubeDownloader;

public partial class App
{
    private static Assembly Assembly { get; } = Assembly.GetExecutingAssembly();

    public static string Name { get; } = Assembly.GetName().Name!;

    public static Version Version { get; } = Assembly.GetName().Version!;

    public static string VersionString { get; } = Version.ToString(3);

    public static string ProjectUrl { get; } = "https://github.com/Tyrrrz/YoutubeDownloader";

    public static string ChangelogUrl { get; } = ProjectUrl + "/blob/master/Changelog.md";
}

public partial class App
{
    private static Theme LightTheme { get; } = Theme.Create(
        new MaterialDesignLightTheme(),
        MediaColor.FromHex("#343838"),
        MediaColor.FromHex("#F9A825")
    );

    private static Theme DarkTheme { get; } = Theme.Create(
        new MaterialDesignDarkTheme(),
        MediaColor.FromHex("#E8E8E8"),
        MediaColor.FromHex("#F9A825")
    );

    public static void SetLightTheme()
    {
        var paletteHelper = new PaletteHelper();
        paletteHelper.SetTheme(LightTheme);

        Current.Resources["SuccessBrush"] = new SolidColorBrush(Colors.DarkGreen);
        Current.Resources["CanceledBrush"] = new SolidColorBrush(Colors.DarkOrange);
        Current.Resources["FailedBrush"] = new SolidColorBrush(Colors.DarkRed);
    }

    public static void SetDarkTheme()
    {
        var paletteHelper = new PaletteHelper();
        paletteHelper.SetTheme(DarkTheme);

        Current.Resources["SuccessBrush"] = new SolidColorBrush(Colors.LightGreen);
        Current.Resources["CanceledBrush"] = new SolidColorBrush(Colors.Orange);
        Current.Resources["FailedBrush"] = new SolidColorBrush(Colors.OrangeRed);
    }
}